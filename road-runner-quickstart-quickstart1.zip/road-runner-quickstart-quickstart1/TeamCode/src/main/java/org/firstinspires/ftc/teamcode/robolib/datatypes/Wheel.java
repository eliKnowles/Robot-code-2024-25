package org.firstinspires.ftc.teamcode.robolib.datatypes;

public enum Wheel {
    FR, FL, BR, BL;
}